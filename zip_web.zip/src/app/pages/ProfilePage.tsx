import { useAuth } from '../../contexts/AuthContext';
import { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../../firebase/firebaseConfig';

import {
  LogOut,
  User,
  MapPin,
  Package
} from 'lucide-react';

export function ProfilePage() {
  const { user, logout } = useAuth();

  const [orders, setOrders] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;

      try {
        const q = query(
          collection(db, 'orders'),
          where('userId', '==', user.uid),
          orderBy('createdAt', 'desc')
        );

        const querySnapshot = await getDocs(q);

        const ordersData = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));

        setOrders(ordersData);

      } catch (error) {
        console.error('Error cargando pedidos:', error);

      } finally {
        setLoadingOrders(false);
      }
    };

    fetchOrders();
  }, [user]);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        <div className="bg-card rounded-2xl border border-border overflow-hidden">

          {/* Header */}
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-8">
            <div className="flex items-center gap-6">

              <img
                src={user.photoURL || ''}
                alt={user.displayName || ''}
                className="w-24 h-24 rounded-full border-4 border-white shadow-lg"
              />

              <div className="flex-1">
                <h1 className="text-2xl font-bold text-foreground mb-1">
                  {user.displayName}
                </h1>

                <p className="text-muted-foreground">
                  {user.email}
                </p>
              </div>

              <button
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:opacity-90 transition-opacity"
              >
                <LogOut className="w-4 h-4" />
                Cerrar sesión
              </button>

            </div>
          </div>

          {/* Contenido */}
          <div className="p-8 space-y-6">

            {/* Información personal */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <User className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-semibold text-foreground">
                  Información Personal
                </h2>
              </div>

              <div className="bg-muted/30 rounded-lg p-4 space-y-3">

                <div>
                  <label className="text-sm text-muted-foreground">
                    Nombre completo
                  </label>

                  <p className="text-foreground">
                    {user.displayName}
                  </p>
                </div>

                <div>
                  <label className="text-sm text-muted-foreground">
                    Correo electrónico
                  </label>

                  <p className="text-foreground">
                    {user.email}
                  </p>
                </div>

              </div>
            </div>

            {/* Dirección */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-primary" />

                <h2 className="text-xl font-semibold text-foreground">
                  Dirección de Envío
                </h2>
              </div>

              <div className="bg-muted/30 rounded-lg p-4">

                <p className="text-muted-foreground text-sm">
                  No has agregado una dirección de envío.
                </p>

                <button className="mt-3 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity">
                  Agregar dirección
                </button>

              </div>
            </div>

            {/* Historial */}
            <div>

              <div className="flex items-center gap-2 mb-4">
                <Package className="w-5 h-5 text-primary" />

                <h2 className="text-xl font-semibold text-foreground">
                  Historial de Pedidos
                </h2>
              </div>

              <div className="space-y-4">

                {loadingOrders ? (

                  <div className="bg-muted/30 rounded-lg p-4">
                    <p className="text-muted-foreground text-sm">
                      Cargando pedidos...
                    </p>
                  </div>

                ) : orders.length === 0 ? (

                  <div className="bg-muted/30 rounded-lg p-4">
                    <p className="text-muted-foreground text-sm">
                      Aún no has realizado ningún pedido.
                    </p>
                  </div>

                ) : (

                  orders.map((order: any) => (

                    <div
                      key={order.id}
                      className="bg-muted/30 rounded-lg p-4 border border-border"
                    >

                      <div className="flex justify-between items-center mb-4">

                        <div>
                          <p className="font-semibold text-foreground">
                            Pedido #{order.id.slice(0, 8)}
                          </p>

                          <p className="text-sm text-muted-foreground">
                            Estado: {order.status}
                          </p>
                        </div>

                        <p className="font-bold text-primary">
                          ${order.total} MXN
                        </p>

                      </div>

                      <div className="space-y-3">

                        {order.items.map((item: any) => (

                          <div
                            key={item.id}
                            className="flex items-center gap-3"
                          >

                            <img
                              src={item.imageUrl}
                              alt={item.name}
                              className="w-14 h-14 rounded-lg object-cover bg-muted"
                            />

                            <div className="flex-1">

                              <p className="font-medium text-foreground">
                                {item.name}
                              </p>

                              <p className="text-sm text-muted-foreground">
                                Cantidad: {item.quantity}
                              </p>

                            </div>

                            <p className="font-semibold text-primary">
                              ${item.price * item.quantity} MXN
                            </p>

                          </div>

                        ))}

                      </div>

                    </div>

                  ))

                )}

              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}