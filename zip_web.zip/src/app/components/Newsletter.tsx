import { Mail } from 'lucide-react';

export function Newsletter() {
  return (
    <section className="py-16 bg-gradient-to-br from-primary to-primary/90">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Mail className="w-8 h-8 text-white" />
        </div>

        <h2 className="text-3xl font-bold text-white mb-3">
          Únete a nuestra comunidad
        </h2>
        <p className="text-white/90 mb-8 max-w-2xl mx-auto">
          Recibe consejos sobre ejercicio durante tu ciclo, ofertas exclusivas y novedades de FlowFit
        </p>

        <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
          <input
            type="email"
            placeholder="Tu correo electrónico"
            className="flex-1 px-4 py-3 rounded-lg bg-white/95 backdrop-blur-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-white"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-white text-primary rounded-lg font-medium hover:bg-white/90 transition-colors"
          >
            Suscribirme
          </button>
        </form>

        <p className="text-white/70 text-sm mt-4">
          🔒 Tu privacidad es importante para nosotras
        </p>
      </div>
    </section>
  );
}
