export function CycleInfo() {
  const phases = [
    {
      phase: 'Menstrual',
      days: '1-5',
      recommendation: 'Máxima protección',
      color: 'bg-primary/20 border-primary'
    },
    {
      phase: 'Folicular',
      days: '6-13',
      recommendation: 'Protección moderada',
      color: 'bg-secondary/20 border-secondary'
    },
    {
      phase: 'Ovulación',
      days: '14-16',
      recommendation: 'Protección ligera',
      color: 'bg-accent/20 border-accent'
    },
    {
      phase: 'Lútea',
      days: '17-28',
      recommendation: 'Adaptable',
      color: 'bg-muted border-muted-foreground/30'
    }
  ];

  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-accent/10 to-secondary/10 rounded-3xl p-8 lg:p-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-3">
              Entiende tu ciclo menstrual
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Adapta tu rutina de ejercicio y protección según cada fase de tu ciclo
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            {phases.map((item) => (
              <div
                key={item.phase}
                className={`${item.color} border-2 rounded-xl p-6 space-y-3 hover:shadow-md transition-shadow`}
              >
                <div className="text-sm font-semibold text-muted-foreground">
                  Días {item.days}
                </div>
                <h3 className="text-xl font-bold text-foreground">
                  {item.phase}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {item.recommendation}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <button className="px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity">
              Descubre tu plan personalizado
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
