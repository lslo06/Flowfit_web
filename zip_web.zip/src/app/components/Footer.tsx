import { Instagram, Facebook, Twitter } from 'lucide-react';
import logo from '../../imports/Diseño_sin_título__3_-removebg-preview-1.png';

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <img src={logo} alt="FlowFit" className="h-10 w-10" />
              <span className="font-semibold text-xl text-foreground">FlowFit</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Tu aliada en cada fase del ciclo. Productos diseñados para mujeres activas.
            </p>
            <div className="flex gap-3">
              <a href="#" className="p-2 bg-muted rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-muted rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-muted rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Productos</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Toallas Alta Absorción</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Toallas Deportivas</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Copas Menstruales</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Ropa Interior</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Información</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Sobre Nosotras</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Blog</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Guía del Ciclo</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Contacto</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-foreground mb-4">Ayuda</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Preguntas Frecuentes</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Envíos y Devoluciones</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Políticas de Privacidad</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Términos y Condiciones</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>© 2026 FlowFit. Todos los derechos reservados. Diseñado con ❤️ para mujeres activas.</p>
        </div>
      </div>
    </footer>
  );
}
