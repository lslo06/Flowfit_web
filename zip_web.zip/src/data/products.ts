import indNegro from '../imports/ind_negro.jpg';
import indRosa from '../imports/ind_rosa.jpg';
import indMorado from '../imports/ind_morado.jpg';
import indCrema from '../imports/ind_crema.jpg';
import indCopa from '../imports/ind_copa.png';
import indDisc from '../imports/ind_disc.jpg';
import packImg from '../imports/pack.jpg';
import packImg2 from '../imports/pack_2.jpg';
import packImg3 from '../imports/pack_3.jpg';
import packImg4 from '../imports/pack_4.jpg';

export type ProductType = 'individual' | 'pack';

export interface Product {
  id: number;
  name: string;
  price: number;
  type: ProductType;
  description: string;
  imageUrl: string;
  badge?: string;
  includes?: string[];
}

export const PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Flow Sport Negro',
    price: 549,
    type: 'individual',
    description: 'Calzón menstrual deportivo de alto rendimiento',
    imageUrl: indNegro,
    badge: 'Más vendido'
  },
  {
    id: 2,
    name: 'Flow Sport Rosa',
    price: 549,
    type: 'individual',
    description: 'Calzón menstrual deportivo en tono rosado',
    imageUrl: indRosa
  },
  {
    id: 3,
    name: 'Flow Sport Morado',
    price: 549,
    type: 'individual',
    description: 'Calzón menstrual deportivo en tono morado',
    imageUrl: indMorado,
    badge: 'Nuevo'
  },
  {
    id: 4,
    name: 'Flow Sport Crema',
    price: 299,
    type: 'individual',
    description: 'Crema calmante para aliviar molestias del ciclo',
    imageUrl: indCrema
  },
  {
    id: 5,
    name: 'Copa menstrual FlowFit',
    price: 585,
    type: 'individual',
    description: 'Copa reutilizable de silicona médica',
    imageUrl: indCopa
  },
  {
    id: 6,
    name: 'Disco menstrual FlowFit',
    price: 699,
    type: 'individual',
    description: 'Disco reutilizable para mayor libertad de movimiento',
    imageUrl: indDisc
  },
  {
    id: 7,
    name: 'Pack Starter',
    price: 1349,
    type: 'pack',
    description: 'Ideal para comenzar tu experiencia FlowFit',
    imageUrl: packImg,
    badge: 'Ahorra $149',
    includes: ['Flow Sport Negro', 'Copa menstrual FlowFit']
  },
  {
    id: 8,
    name: 'Pack disc flow',
    price: 1749,
    type: 'pack',
    description: 'Para entrenadoras de alto rendimiento',
    imageUrl: packImg2,
    badge: 'Más popular',
    includes: ['Flow Sport Rosa', 'Flow Sport Morado', 'Disco menstrual FlowFit']
  },
  {
    id: 9,
    name: 'Pack copa flow',
    price: 1849,
    type: 'pack',
    description: 'El paquete completo para guerreras FlowFit',
    imageUrl: packImg3,
    badge: 'Mejor valor',
    includes: ['Flow Sport Negro', 'Flow Sport Rosa', 'Copa menstrual', 'Crema FlowFit']
  },
  {
    id: 10,
    name: 'Pack Libertad total',
    price: 2495,
    type: 'pack',
    description: 'El paquete completo para guerreras FlowFit',
    imageUrl: packImg4,
    badge: 'Mejor valor',
    includes: ['Flow Sport Negro', 'Flow Sport Rosa', 'Copa menstrual', 'Crema FlowFit']
  }
];
