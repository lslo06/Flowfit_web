import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebaseConfig';
import { useAuth } from './AuthContext';

export interface FavoriteItem {
  id: number;
  name: string;
  price: number;
  imageUrl: string;
}

interface FavoritesContextType {
  favorites: FavoriteItem[];
  addToFavorites: (product: FavoriteItem) => void;
  removeFromFavorites: (productId: number) => void;
  isFavorite: (productId: number) => boolean;
  favoritesCount: number;
}

const FavoritesContext = createContext<FavoritesContextType>({
  favorites: [],
  addToFavorites: () => {},
  removeFromFavorites: () => {},
  isFavorite: () => false,
  favoritesCount: 0
});

export const useFavorites = () => useContext(FavoritesContext);

interface FavoritesProviderProps {
  children: ReactNode;
}

export function FavoritesProvider({ children }: FavoritesProviderProps) {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadFavoritesFromFirestore();
    } else {
      setFavorites([]);
    }
  }, [user]);

  const loadFavoritesFromFirestore = async () => {
    if (!user) return;

    try {
      const favRef = doc(db, 'users', user.uid);
      const favDoc = await getDoc(favRef);

      if (favDoc.exists() && favDoc.data().favorites) {
        const favData = favDoc.data().favorites;
        const favArray = Object.values(favData) as FavoriteItem[];
        setFavorites(favArray);
      }
    } catch (error) {
      console.error("Error al cargar favoritos:", error);
    }
  };

  const saveFavoritesToFirestore = async (updatedFavorites: FavoriteItem[]) => {
    if (!user) return;

    try {
      const favRef = doc(db, 'users', user.uid);
      const favObject = updatedFavorites.reduce((acc, item) => {
        acc[item.id] = item;
        return acc;
      }, {} as Record<number, FavoriteItem>);

      await setDoc(favRef, { favorites: favObject }, { merge: true });
    } catch (error) {
      console.error("Error al guardar favoritos:", error);
    }
  };

  const addToFavorites = (product: FavoriteItem) => {
    setFavorites((prevFavorites) => {
      const exists = prevFavorites.find((item) => item.id === product.id);
      if (exists) return prevFavorites;

      const updatedFavorites = [...prevFavorites, product];
      saveFavoritesToFirestore(updatedFavorites);
      return updatedFavorites;
    });
  };

  const removeFromFavorites = (productId: number) => {
    setFavorites((prevFavorites) => {
      const updatedFavorites = prevFavorites.filter((item) => item.id !== productId);
      saveFavoritesToFirestore(updatedFavorites);
      return updatedFavorites;
    });
  };

  const isFavorite = (productId: number) => {
    return favorites.some((item) => item.id === productId);
  };

  const favoritesCount = favorites.length;

  return (
    <FavoritesContext.Provider value={{
      favorites,
      addToFavorites,
      removeFromFavorites,
      isFavorite,
      favoritesCount
    }}>
      {children}
    </FavoritesContext.Provider>
  );
}
