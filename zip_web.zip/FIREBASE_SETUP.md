# 🔥 Configuración de Firebase - Guía Completa

Esta guía te llevará paso a paso para configurar Firebase desde cero para FlowFit.

---

## 📋 Requisitos Previos

- ✅ Cuenta de Google
- ✅ Proyecto FlowFit descargado
- ✅ Node.js instalado

---

## 🚀 Paso 1: Crear Proyecto en Firebase

### 1.1. Acceder a Firebase Console

1. Abre tu navegador y ve a: **https://console.firebase.google.com**
2. Inicia sesión con tu cuenta de Google
3. Haz clic en **"Agregar proyecto"** o **"Create a project"**

### 1.2. Configurar el Proyecto

**Pantalla 1: Nombre del proyecto**
- Nombre: `flowfit` (puedes usar el que prefieras)
- Click en **Continuar**

**Pantalla 2: Google Analytics**
- Desactiva el toggle de Google Analytics (no es necesario por ahora)
- O déjalo activado si quieres estadísticas (opcional)
- Click en **Crear proyecto**

**Pantalla 3: Esperar...**
- Firebase creará tu proyecto (toma ~30 segundos)
- Click en **Continuar** cuando termine

✅ **¡Proyecto creado exitosamente!**

---

## 🔑 Paso 2: Obtener Credenciales de Firebase

### 2.1. Registrar App Web

1. En Firebase Console, ve al **ícono de configuración ⚙️** (arriba a la izquierda)
2. Click en **"Configuración del proyecto"** o **"Project settings"**
3. Scroll hacia abajo hasta la sección **"Tus apps"** o **"Your apps"**
4. Click en el ícono **`</>`** (Web)

### 2.2. Configurar la App

- **Alias de la app:** `FlowFit Web`
- **Firebase Hosting:** NO marques la casilla
- Click en **"Registrar app"**

### 2.3. Copiar Credenciales

Verás algo como esto - **COPIA ESTOS VALORES:**

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyAbCdEfGh...",
  authDomain: "flowfit-abc123.firebaseapp.com",
  projectId: "flowfit-abc123",
  storageBucket: "flowfit-abc123.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc123",
  measurementId: "G-ABC123XYZ"
};
```

---

## Ver el archivo completo en: /workspaces/default/code/FIREBASE_SETUP.md
